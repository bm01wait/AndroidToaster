package com.binhminh.assignment3;

import android.content.Context;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.binhminh.assignment3.dialog.ViewPhoneDialog;
import com.binhminh.assignment3.model.Animal;


public class DetailActivity extends AppCompatActivity {
    private static final String LOG_TAG = "LOG_TAG";
    ImageView imgViewFav, imgViewContent;
    TextView textViewMain, txtViewContent, txtViewPhone;
    boolean fav;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    Broadcast broadcast;
    ImageView buttonOpenDialog;
    String tel;
    Animal animal;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_detail);
        Bundle bundle = getIntent().getExtras();
        if (bundle == null) {
            return;
        }
        animal = (Animal) bundle.get("KEY");
        textViewMain = findViewById(R.id.tv_animal_name);
        txtViewContent = findViewById(R.id.tv_animal_desc);
        imgViewFav = findViewById(R.id.ib_favorite);
        imgViewContent = findViewById(R.id.iv_animal);
        txtViewPhone = findViewById(R.id.txtViewPhone);
        sharedPreferences = getSharedPreferences("file_savef", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();

        textViewMain.setText(animal.getName());
        txtViewContent.setText(animal.getContent());
        for (int i = 1; i <=6 ; i++) {
            String tele = getSharedPreferences("file_savef", Context.MODE_PRIVATE).getString("TEL"+String.valueOf(i), tel);
            if(animal.getPath().equals(String.valueOf(i))) { txtViewPhone.setText(tele);}
        }
        imgViewContent.setImageResource(animal.getPhotoBg());
        if (animal.isFav()) {
            imgViewFav.setImageResource(R.drawable.ic_favorite2);
        }
        else {
            imgViewFav.setImageResource(R.drawable.ic_favorite1);
        }
        imgViewFav.setOnClickListener(v -> {
            if (fav) {
                imgViewFav.setImageResource(R.drawable.ic_favorite1);
                fav = false;
            }
            else {
                imgViewFav.setImageResource(R.drawable.ic_favorite2);
                fav = true;
            }
            for (int i = 1; i <=6 ; i++) {
                if(animal.getPath().equals(String.valueOf(i))) { editor.putBoolean("FAV"+String.valueOf(i), fav);}
            }
            editor.apply();
        });
        broadcast = new Broadcast();
        IntentFilter filter = new IntentFilter("PhoneStateListener.LISTEN_CALL_STATE");
        registerReceiver(broadcast, filter);
        buttonOpenDialog = findViewById(R.id.btn_call);
        buttonOpenDialog.setOnClickListener(view -> {
            ViewPhoneDialog.FullNameListener listener = fullName -> {
                txtViewPhone.setText(fullName);
                for (int i = 1; i <=6 ; i++) {
                    if(animal.getPath().equals(String.valueOf(i))) {
                        tel = fullName;
                        editor.putString("TEL"+String.valueOf(i), tel);
                    }
                }
                editor.apply();
            };
            final ViewPhoneDialog dialog = new ViewPhoneDialog(this, listener);
            dialog.show();
        });
        imgViewFav.setOnClickListener(v -> {
            if (fav) {
                imgViewFav.setImageResource(R.drawable.ic_favorite1);
                fav = false;
            }
            else {
                imgViewFav.setImageResource(R.drawable.ic_favorite2);
                fav = true;
            }
            for (int i = 1; i <= 6; i++) {
                if(animal.getPath().equals(String.valueOf(i))) { editor.putBoolean("FAV"+String.valueOf(i), fav);}
            }
            editor.apply();
        });

        TelephonyManager telephony = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        telephony.listen(new PhoneStateListener() {
            @Override
            public void onCallStateChanged(int state, String incomingNumber) {
                super.onCallStateChanged(state, incomingNumber);
                switch (state) {
                    case TelephonyManager.CALL_STATE_IDLE:
                        Log.i(LOG_TAG,"State : IDLE");
                        break;
                    case TelephonyManager.CALL_STATE_OFFHOOK:
                        Log.i(LOG_TAG,"State : OFFHOOK");
                        break;
                    case TelephonyManager.CALL_STATE_RINGING:
                        Log.i(LOG_TAG,"State : RING RING");
                        if (incomingNumber.equals((String) txtViewPhone.getText())) {
                            Toast.makeText(DetailActivity.this, incomingNumber, Toast.LENGTH_SHORT).show();
                            if (animal.getPath().equals("1")) {
                                CustomToast.makeText(DetailActivity.this,"",CustomToast.LENGTH_SHORT,CustomToast.animal1,true).show();
                            }
                            if (animal.getPath().equals("2")){
                                CustomToast.makeText(DetailActivity.this,"",CustomToast.LENGTH_SHORT,CustomToast.animal2,true).show();
                            }
                            if (animal.getPath().equals("3")){
                                CustomToast.makeText(DetailActivity.this,"",CustomToast.LENGTH_SHORT,CustomToast.animal3,true).show();
                            }
                            if (animal.getPath().equals("4")){
                                CustomToast.makeText(DetailActivity.this,"",CustomToast.LENGTH_SHORT,CustomToast.animal4,true).show();
                            }
                            if (animal.getPath().equals("5")){
                                CustomToast.makeText(DetailActivity.this,"",CustomToast.LENGTH_SHORT,CustomToast.animal5,true).show();
                            }
                            if (animal.getPath().equals("6")){
                                CustomToast.makeText(DetailActivity.this,"",CustomToast.LENGTH_SHORT,CustomToast.animal6,true).show();
                           }
                        }
                        break;
                }
            }
        }, PhoneStateListener.LISTEN_CALL_STATE);
    }


}
