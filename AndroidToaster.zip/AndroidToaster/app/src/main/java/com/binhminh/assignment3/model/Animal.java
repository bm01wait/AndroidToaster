package com.binhminh.assignment3.model;

import android.graphics.Bitmap;

import java.io.Serializable;


public class Animal implements Serializable {
    private final int photo;
    private final int photoBg;
    private final String path;
    private final String name;
    private final String content;
    private boolean isFav;

    public void setFav(boolean fav) {
        isFav = fav;
    }
    public boolean isFav() {
        return isFav;
    }
    public Animal(String path, int photo, int photoBg, String name, String content, boolean isFav) {
        this.path = path;
        this.photo = photo;
        this.photoBg = photoBg;
        this.name = name;
        this.isFav = isFav;
        this.content = content;
    }
    public String getPath() {
        return path;
    }
    public int getPhoto() {
        return photo;
    }
    public int getPhotoBg() {
        return photoBg;
    }
    public String getContent() {
        return content;
    }
    public String getName() {
            return name;
    }
}
