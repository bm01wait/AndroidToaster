package com.binhminh.assignment3.dialog;

//import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import com.binhminh.assignment3.model.Animal;

import com.binhminh.assignment3.R;

//import java.util.Objects;

public class ViewPhoneDialog extends Dialog {
//    SharedPreferences sharedPreferences;
//    SharedPreferences.Editor editor;
    EditText etData;
    Button btnSave;
    Button btnClear;
    ViewPhoneDialog.FullNameListener listener;
    Context context;
    ImageView imgViewIcon;
    public ViewPhoneDialog(Context context, ViewPhoneDialog.FullNameListener listener) {
        super(context);
        this.context = context;
        this.listener = listener;
    }

    public interface FullNameListener {
        void fullNameEntered(String fullName);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.call_menu);

        this.etData = findViewById(R.id.et_data);
        this.btnSave = findViewById(R.id.btn_save);
        this.btnClear = findViewById(R.id.btn_clear);
        this.imgViewIcon = findViewById(R.id.iv_icon);
//        savedData = sharedPreferences.getString("elephant", "");
//        etData.setText(savedData);
        this.btnSave .setOnClickListener(v -> buttonOKClick());
        this.btnClear .setOnClickListener(v -> btnClearClick());
    }


    private void buttonOKClick()  {
        String fullName = this.etData.getText().toString();
//        editor.putString("elephant", "");
//        editor.commit(); // Close Dialog
        if(fullName.isEmpty())  {
            Toast.makeText(this.context, "Please enter your phone", Toast.LENGTH_LONG).show();
            return;
        }
        this.dismiss(); // Close Dialog
        if(this.listener != null)  {
            this.listener.fullNameEntered(fullName);
        }
    }

    // User click "Cancel" button.
    private void btnClearClick()  {
//        etData.setText("");
//        editor.remove("elephant");
//        editor.commit();
        this.dismiss();
    }
}
