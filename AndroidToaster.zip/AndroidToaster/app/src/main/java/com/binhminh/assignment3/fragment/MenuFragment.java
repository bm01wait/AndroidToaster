package com.binhminh.assignment3.fragment;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.binhminh.assignment3.R;
import com.binhminh.assignment3.adapter.AnimalAdapter;
import com.binhminh.assignment3.model.Animal;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class MenuFragment extends Fragment {
    private Context mContext;
    private RecyclerView rvAnimal;
    private ArrayList<Animal> listAnimals;
    private DrawerLayout mDrawer;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_menu, container, false);
        initView(v);
        return v;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mContext = context;
    }

    private void initView(View v) {
        mDrawer = v.findViewById(R.id.drawer);
        rvAnimal = v.findViewById(R.id.rv_animals);
        //Xử lý mở menu trái
        v.findViewById(R.id.iv_menu).setOnClickListener(v12 -> mDrawer.openDrawer(GravityCompat.START));

       //Hiển thị ảnh động vật biển
        v.findViewById(R.id.iv_sea).setOnClickListener(v1 -> {
            v.startAnimation(AnimationUtils.loadAnimation(mContext, R.anim.alpha));
            showAnimals("sea");
        });

        //Hiển thị ảnh động vật có vú
        v.findViewById(R.id.iv_mammal).setOnClickListener(v1 -> {
            v.startAnimation(AnimationUtils.loadAnimation(mContext, R.anim.alpha));
            showAnimals("mammal");
        });
        //Hiển thị ảnh chim muông
        v.findViewById(R.id.iv_bird).setOnClickListener(v1 -> {
            v.startAnimation(AnimationUtils.loadAnimation(mContext, R.anim.alpha));
            showAnimals("bird");
        });

        //Hiển thị danh sách ảnh lên RecyclerView
        if (listAnimals != null) {
            AnimalAdapter animalAdapter = new AnimalAdapter(mContext, listAnimals);
            rvAnimal.setAdapter(animalAdapter);
        }
    }

    private void showAnimals(String path) {
        listAnimals = new ArrayList<>();
        try {
            String content1 = "", content2 = "", content3 = "";
            String content4 = "", content5 = "", content6 = "";
            //Học sinh tự code để đọc dữ liệu text từ đường dẫn fileText trong thư mục assets vào tham số content
            try {
                InputStream in1 = mContext.getAssets().open("description/des_bugs.txt");
                InputStream in2 = mContext.getAssets().open("description/des_goose.txt");
                InputStream in3 = mContext.getAssets().open("description/des_dog.txt");
                InputStream in4 = mContext.getAssets().open("description/des_elephant.txt");
                InputStream in5 = mContext.getAssets().open("description/des_penguin.txt");
                InputStream in6 = mContext.getAssets().open("description/des_tortoise.txt");
                byte[] buffer1 = new byte[in1.available()];  // cấp cho bộ nhớ đúng bằng kích thước của file,
                byte[] buffer2 = new byte[in2.available()];
                byte[] buffer3 = new byte[in3.available()];
                byte[] buffer4 = new byte[in4.available()];
                byte[] buffer5 = new byte[in5.available()];
                byte[] buffer6 = new byte[in6.available()];
                in1.read(buffer1);               //đây là cách nguy hiểm khi đọc file có kích thước 1gb trở lên
                in2.read(buffer2);
                in3.read(buffer3);
                in4.read(buffer4);
                in5.read(buffer5);
                in6.read(buffer6);
                content1 = new String(buffer1);
                content2 = new String(buffer2);
                content3 = new String(buffer3);
                content4 = new String(buffer4);
                content5 = new String(buffer5);
                content6 = new String(buffer6);
                in1.close();
                in2.close();
                in3.close();
                in4.close();
                in5.close();
                in6.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            //Lấy thông tin động vật yêu thích đã lưu trữ trong file_savef của SharedPreference
            boolean isLove1 = mContext.getSharedPreferences("file_savef", Context.MODE_PRIVATE).getBoolean("FAV1", false);
            boolean isLove2 = mContext.getSharedPreferences("file_savef", Context.MODE_PRIVATE).getBoolean("FAV2", false);
            boolean isLove3 = mContext.getSharedPreferences("file_savef", Context.MODE_PRIVATE).getBoolean("FAV3", false);
            boolean isLove4 = mContext.getSharedPreferences("file_savef", Context.MODE_PRIVATE).getBoolean("FAV4", false);
            boolean isLove5 = mContext.getSharedPreferences("file_savef", Context.MODE_PRIVATE).getBoolean("FAV5", false);
            boolean isLove6 = mContext.getSharedPreferences("file_savef", Context.MODE_PRIVATE).getBoolean("FAV6", false);
            //Cho vào danh sách
            if (path.equals("bird")) {
                listAnimals.add(new Animal("1", R.drawable.ic_bug, R.drawable.bug, "Bug", content1, isLove1));
                listAnimals.add(new Animal("2", R.drawable.ic_goose, R.drawable.goose, "Goose", content2, isLove2));
            }
            if (path.equals("mammal")) {
                listAnimals.add(new Animal("3", R.drawable.ic_dog, R.drawable.dog, "Dog", content3, isLove3));
                listAnimals.add(new Animal("4", R.drawable.ic_elephant, R.drawable.elephant, "Elephant", content4, isLove4));
            }
            if (path.equals("sea")) {
                listAnimals.add(new Animal("5", R.drawable.ic_penguin, R.drawable.penguin, "Penguin", content5, isLove5));
                listAnimals.add(new Animal("6", R.drawable.ic_tortoise, R.drawable.tortoise, "Tortoise", content6, isLove6));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        //Hiển thị danh sách ảnh lên RecyclerView
        AnimalAdapter animalAdapter = new AnimalAdapter(mContext, listAnimals);
//        AnimalAdapter animalAdapter = new AnimalAdapter(listAnimals, mContext, v -> doCLickAnimal((Animal) v.getTag()));
        rvAnimal.setAdapter(animalAdapter);
        mDrawer.closeDrawers();
    }
}
