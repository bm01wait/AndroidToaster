package com.binhminh.assignment3.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.binhminh.assignment3.DetailActivity;
import com.binhminh.assignment3.R;
import com.binhminh.assignment3.model.Animal;

import java.util.ArrayList;

public class AnimalAdapter extends RecyclerView.Adapter<AnimalAdapter.ViewHolder> {
    Context context;
    ArrayList<Animal> listAnimal;
    
    public AnimalAdapter(Context context, ArrayList<Animal> listAnimal) {
        this.context = context;
        this.listAnimal = listAnimal;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // gán view
        View view = LayoutInflater.from(context).inflate(R.layout.item_animal, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Gán dữ liêuk
        Animal animal = listAnimal.get(position);
//        holder.tv_animal_name.setText(animal.getName());
//        holder.tv_animal_desc.setText(animal.getContent());
//        holder.ib_favorite.setImageResource(R.drawable.ic_favorite1);
//        holder.iv_animal.setImageResource(animal.getPhotoBg());
        if (animal.isFav()) {
            holder.imageView.setImageResource(R.drawable.ic_favorite2);
        }
        else {
            holder.imageView.setImageResource(R.drawable.ic_favorite1);
        }
        holder.imageButton01.setImageResource(animal.getPhoto());
        holder.imageButton01.setOnClickListener(v -> onClickGoToDetail(animal));
    }

    private void onClickGoToDetail(Animal animal) {
        Intent intent = new Intent(context, DetailActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("KEY", animal);
        intent.putExtras(bundle);
        context.startActivity(intent);
    }

    @Override
    public int getItemCount() {
        return listAnimal.size(); // trả item tại vị trí postion
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ib_favorite, iv_animal, imageView;
        TextView tv_animal_name, tv_animal_desc;
        ImageButton imageButton01;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // Ánh xạ view
//            ib_favorite = itemView.findViewById(R.id.ib_favorite);
//            tv_animal_name = itemView.findViewById(R.id.tv_animal_name);
//            iv_animal = itemView.findViewById(R.id.iv_animal);
//            tv_animal_desc = itemView.findViewById(R.id.tv_animal_desc);
            imageButton01 = itemView.findViewById(R.id.imageButton01);
            imageView = itemView.findViewById(R.id.imageView);
        }
    }
}

