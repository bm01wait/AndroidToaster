package com.binhminh.assignment3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class CustomToast extends Toast {

    public static int animal1 = 1;
    public static int animal2 = 2;
    public static int animal3 = 3;
    public static int animal4 = 4;
    public static int animal5 = 5;
    public static int animal6 = 6;


    public CustomToast(Context context) {
        super(context);
    }

    public static Toast makeText(Context context, String message, int duration, int type, boolean androidicon) {
        Toast toast = new Toast(context);
        toast.setDuration(duration);
        View layout = LayoutInflater.from(context).inflate(R.layout.custom_toast, null, false);
        ImageView img = layout.findViewById(R.id.imageView4);
        if (type == 1) {
            img.setImageResource(R.drawable.ic_bug);
        } else if (type == 2) {
            img.setImageResource(R.drawable.ic_goose);
        } else if (type == 3) {
            img.setImageResource(R.drawable.ic_dog);
        } else if (type == 4) {
            img.setImageResource(R.drawable.ic_elephant);
        } else if (type == 5) {
            img.setImageResource(R.drawable.ic_penguin);
        } else if (type == 6) {
            img.setImageResource(R.drawable.ic_tortoise);
        }
        toast.setView(layout);
        return toast;
    }
}
